<?php
// Open your eyes, and nothing here, lolzz =))